# Stars Shop — Mini App Frontend (React + Vite + Tailwind)

Telegram Mini App sifatida ochiladigan katalog: foydalanuvchi Stars paketini
tanlaydi, Telegram'ning o'z to'lov oynasida (`openInvoice`) to'laydi, buyurtma
tarixini va bonuslarini ko'radi.

Bu ilova hech qanday ma'lumotni o'zida saqlamaydi — hammasi `stars-backend`dagi
`/api/public/*` endpointlaridan olinadi, ular esa Telegram `initData` orqali
so'rov qaysi foydalanuvchidan kelayotganini tekshiradi.

## Loyiha tuzilishi

```
stars-frontend/
├── index.html                 # Telegram WebApp SDK shu yerdan ulanadi
├── src/
│   ├── main.tsx                 # Kirish nuqtasi, Telegram SDK'ni ishga tushiradi
│   ├── App.tsx                   # Tab navigatsiyasi (Home/Orders/Referral/Profile)
│   ├── pages/
│   │   ├── Home.tsx                # Paketlar katalogi, sotib olish oqimi
│   │   ├── Orders.tsx                # Buyurtmalar tarixi
│   │   ├── Referral.tsx               # Referal havolasi
│   │   └── Profile.tsx                 # Statistika, support
│   ├── components/                      # ProductCard, StatusBadge, BottomNav, Toast, StarIcon
│   ├── lib/
│   │   ├── telegram.ts                    # Telegram WebApp SDK wrapper
│   │   ├── api.ts                          # Backend bilan muloqot
│   │   └── toast.tsx                        # Global bildirishnoma
│   └── types.ts                              # Backend bilan bir xil tiplar
├── tailwind.config.ts            # Ranglar Telegram tema o'zgaruvchilariga bog'langan
├── package.json / vite.config.ts / tsconfig*.json
├── Dockerfile + nginx.conf        # Ixtiyoriy — o'zingiz hostlash uchun
└── .env.example
```

## Dizayn yondashuvi

- **Ranglar** — Telegram o'zi runtime'da beradigan `themeParams` (bg, text,
  hint, button va h.k.) `src/lib/telegram.ts` orqali CSS o'zgaruvchilariga
  yoziladi va Tailwind shulardan foydalanadi (`tgbg`, `tgtext`, `tgbutton`...).
  Shu sababli foydalanuvchining Telegram'dagi dark/light rejimiga **avtomatik**
  moslashadi — alohida toggle kerak emas.
- **Star aksenti** — Telegram Stars belgisining o'zidagi oltin rang
  (`#FFB300 → #FFD65A`), faqat "eng ommabop" paket kartochkasida va bir-ikki
  joyda subtil shimmer/float animatsiyasi bilan ishlatilgan.
- **Shrift** — tizim shriftlari (SF Pro / Roboto / Segoe UI) — Telegram'ning
  o'z ilovasiga vizual jihatdan mos tushishi uchun.

## Mahalliy ishga tushirish

1. Node.js 20+ o'rnatilgan bo'lsin.
2. Kutubxonalarni o'rnating:
   ```bash
   npm install
   ```
3. `.env.example`dan nusxa oling:
   ```bash
   cp .env.example .env
   ```
   - `VITE_API_BASE_URL` — `stars-backend` manzili.
   - `VITE_BOT_USERNAME` — botingiz username'i (referal havolasi uchun).
4. Ishga tushiring:
   ```bash
   npm run dev
   ```
   Brauzerda ochilganda Telegram SDK topilmaydi — ilova baribir ishlaydi
   (fallback ranglar bilan), lekin `openInvoice` yangi tabda ochiladi va
   haqiqiy Telegram autentifikatsiyasi bo'lmagani uchun backend `401`
   qaytarishi mumkin. **To'liq test qilish uchun quyidagi bosqichga o'ting.**

## Telegram ichida test qilish

1. Mahalliy serverni tashqi dunyoga ochish uchun tunnel oching (masalan
   [ngrok](https://ngrok.com/)):
   ```bash
   ngrok http 5173
   ```
2. [@BotFather](https://t.me/BotFather)da `/setmenubutton` (yoki `/newapp`)
   orqali shu ngrok HTTPS manzilini bot'ga bog'lang.
3. Botni Telegram'da oching, menyu tugmasi orqali Mini App'ni ishga tushiring —
   endi haqiqiy `initData` bilan ishlaydi.

## Production build va deploy (Vercel)

1. Vercel'da **New Project → Import Git Repository**.
2. Build sozlamalari avtomatik aniqlanadi (Vite): `npm run build`, output
   papkasi `dist`.
3. Vercel "Environment Variables" bo'limida `VITE_API_BASE_URL` va
   `VITE_BOT_USERNAME`ni kiriting.
4. Deploy tugagach, Vercel bergan HTTPS manzilni BotFather'da Mini App
   uchun sozlang, shu manzilni `stars-bot`dagi `WEBAPP_URL`ga ham yozing.

### Muqobil: Railway/nginx orqali

`Dockerfile` va `nginx.conf` shu maqsadda qo'shilgan — agar hammasini bitta
platformada (Railway) ushlab turmoqchi bo'lsangiz, shu Dockerfile orqali ham
deploy qilish mumkin.

## Muhim eslatmalar

- `VITE_*` o'zgaruvchilar build vaqtida kodga yoziladi — shuning uchun
  ularga **hech qachon maxfiy kalit qo'ymang** (masalan `API_INTERNAL_SECRET`
  bu yerga mos emas, u faqat backend/bot orasida qoladi).
- To'lov holatini bu ilova hech qachon o'zi hal qilmaydi — `openInvoice`
  callback orqali kelgan statusni faqat ko'rsatish uchun ishlatadi;
  haqiqiy tasdiqlash backendda, Telegram'ning `successful_payment`
  eventidan keyin bo'ladi (`stars-bot/handlers/payments.py`).
- Bottom nav'dagi 4 bo'lim asl reja bo'yicha: 🏠 Bosh sahifa, 📦 Buyurtmalar,
  🎁 Referal/Bonus, 👤 Profil (Profil ichida Yordam/Support ham bor).

## Keyingi qadamlar

- **Admin panel** — hozircha backend'da admin endpointlar bor (`/api/admin/*`),
  lekin ularga veb interfeys yozilmagan. Xohlasangiz shundan davom etishimiz
  mumkin.
- **Promo kod kiritish maydoni** Home sahifasiga qo'shilishi mumkin (backend
  allaqachon `promo_code` parametrini qo'llab-quvvatlaydi).
- **Bonus balansni referal orqali avtomatik hisoblash** — hozircha
  `referred_by_id` saqlanadi, lekin bonusni buyurtma yakunlanganda avtomatik
  qo'shish logikasi hali yozilmagan.
