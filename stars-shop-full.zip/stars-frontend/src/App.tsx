import { useState } from "react";
import { BottomNav, type Tab } from "./components/BottomNav";
import { Home } from "./pages/Home";
import { Orders } from "./pages/Orders";
import { Profile } from "./pages/Profile";
import { Referral } from "./pages/Referral";

export default function App() {
  const [tab, setTab] = useState<Tab>("home");

  return (
    <div className="mx-auto min-h-screen max-w-md bg-tgbg font-sans">
      <main className="safe-top pb-20">
        {tab === "home" && <Home />}
        {tab === "orders" && <Orders />}
        {tab === "referral" && <Referral />}
        {tab === "profile" && <Profile />}
      </main>
      <BottomNav active={tab} onChange={setTab} />
    </div>
  );
}
