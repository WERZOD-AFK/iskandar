import { haptic } from "../lib/telegram";

export type Tab = "home" | "orders" | "referral" | "profile";

const TABS: { id: Tab; label: string; icon: string }[] = [
  { id: "home", label: "Bosh sahifa", icon: "🏠" },
  { id: "orders", label: "Buyurtmalar", icon: "📦" },
  { id: "referral", label: "Bonuslar", icon: "🎁" },
  { id: "profile", label: "Profil", icon: "👤" },
];

interface BottomNavProps {
  active: Tab;
  onChange: (tab: Tab) => void;
}

export function BottomNav({ active, onChange }: BottomNavProps) {
  return (
    <nav className="safe-bottom fixed inset-x-0 bottom-0 z-20 border-t border-tghint/15 bg-tgbg/95 backdrop-blur">
      <div className="mx-auto flex max-w-md items-stretch justify-around">
        {TABS.map((tab) => {
          const isActive = tab.id === active;
          return (
            <button
              key={tab.id}
              onClick={() => {
                haptic("light");
                onChange(tab.id);
              }}
              className="flex flex-1 flex-col items-center gap-0.5 py-2.5"
            >
              <span className={`text-[20px] leading-none transition-transform ${isActive ? "scale-110" : "opacity-50"}`}>
                {tab.icon}
              </span>
              <span
                className={`text-[10px] font-medium ${isActive ? "text-tgbutton" : "text-tghint"}`}
              >
                {tab.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
