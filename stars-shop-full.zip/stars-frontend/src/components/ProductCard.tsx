import { StarIcon } from "./StarIcon";
import type { Product } from "../types";

interface ProductCardProps {
  product: Product;
  onBuy: (product: Product) => void;
  busy?: boolean;
}

export function ProductCard({ product, onBuy, busy }: ProductCardProps) {
  if (product.is_popular) {
    return (
      <button
        onClick={() => onBuy(product)}
        disabled={busy}
        className="relative w-full overflow-hidden rounded-2xl p-[1px] text-left disabled:opacity-60"
      >
        {/* Signature: yorqin oltin shimmer — faqat eng ommabop paketda */}
        <span
          aria-hidden
          className="absolute inset-0 animate-shimmer bg-[length:200%_100%]"
          style={{
            backgroundImage:
              "linear-gradient(110deg, #FFB300 10%, #FFD65A 30%, #FFB300 50%, #FFD65A 70%, #FFB300 90%)",
          }}
        />
        <span className="relative flex items-center gap-3 rounded-2xl bg-tgbg px-4 py-3.5">
          <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-star/15">
            <StarIcon className="h-6 w-6 animate-float" />
          </span>
          <span className="flex-1">
            <span className="flex items-center gap-1.5">
              <span className="text-[15px] font-semibold tabular-nums text-tgtext">
                {product.stars_amount.toLocaleString("ru-RU")} Stars
              </span>
              <span className="rounded-full bg-star/15 px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide text-star-deep">
                Ommabop
              </span>
            </span>
            <span className="text-[13px] text-tghint">{product.price_stars.toLocaleString("ru-RU")} ⭐ ga</span>
          </span>
          <span className="shrink-0 rounded-full bg-tgbutton px-3.5 py-2 text-[13px] font-semibold text-tgbuttontext">
            {busy ? "..." : "Sotib olish"}
          </span>
        </span>
      </button>
    );
  }

  return (
    <button
      onClick={() => onBuy(product)}
      disabled={busy}
      className="flex flex-col items-start gap-2 rounded-2xl bg-tgsecondary p-3.5 text-left transition-transform active:scale-[0.97] disabled:opacity-60"
    >
      <StarIcon className="h-6 w-6" />
      <span className="text-[15px] font-semibold tabular-nums text-tgtext">
        {product.stars_amount.toLocaleString("ru-RU")}
      </span>
      <span className="text-[12px] text-tghint">{product.price_stars.toLocaleString("ru-RU")} ⭐ ga</span>
    </button>
  );
}
