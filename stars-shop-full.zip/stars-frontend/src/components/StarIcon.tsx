interface StarIconProps {
  className?: string;
  filled?: boolean;
}

export function StarIcon({ className = "", filled = true }: StarIconProps) {
  return (
    <svg viewBox="0 0 24 24" className={className} fill="none" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <linearGradient id="starGradient" x1="0" y1="0" x2="24" y2="24" gradientUnits="userSpaceOnUse">
          <stop offset="0%" stopColor="#FFD65A" />
          <stop offset="100%" stopColor="#FFB300" />
        </linearGradient>
      </defs>
      <path
        d="M12 2.5l2.65 6.02 6.55.58-4.95 4.36 1.48 6.42L12 16.77l-5.73 3.11 1.48-6.42-4.95-4.36 6.55-.58L12 2.5z"
        fill={filled ? "url(#starGradient)" : "none"}
        stroke={filled ? "none" : "currentColor"}
        strokeWidth={filled ? 0 : 1.5}
      />
    </svg>
  );
}
