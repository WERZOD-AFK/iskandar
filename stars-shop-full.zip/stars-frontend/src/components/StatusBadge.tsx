import type { OrderStatus } from "../types";

const STATUS_CONFIG: Record<OrderStatus, { label: string; dot: string; text: string }> = {
  pending: { label: "Kutilmoqda", dot: "bg-amber-400", text: "text-amber-500" },
  paid: { label: "To'lov qilindi", dot: "bg-blue-400", text: "text-blue-500" },
  processing: { label: "Qayta ishlanmoqda", dot: "bg-violet-400", text: "text-violet-500" },
  completed: { label: "Yakunlandi", dot: "bg-emerald-400", text: "text-emerald-500" },
  cancelled: { label: "Bekor qilindi", dot: "bg-red-400", text: "text-red-500" },
};

export function StatusBadge({ status }: { status: OrderStatus }) {
  const cfg = STATUS_CONFIG[status];
  return (
    <span className={`inline-flex items-center gap-1.5 text-[12px] font-medium ${cfg.text}`}>
      <span className={`h-1.5 w-1.5 rounded-full ${cfg.dot}`} />
      {cfg.label}
    </span>
  );
}
