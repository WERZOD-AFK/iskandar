import { useEffect } from "react";

interface ToastProps {
  message: string;
  variant?: "success" | "error" | "info";
  onDone: () => void;
}

const VARIANT_STYLES: Record<NonNullable<ToastProps["variant"]>, string> = {
  success: "bg-emerald-500",
  error: "bg-red-500",
  info: "bg-tgtext",
};

export function Toast({ message, variant = "info", onDone }: ToastProps) {
  useEffect(() => {
    const t = setTimeout(onDone, 2600);
    return () => clearTimeout(t);
  }, [onDone]);

  return (
    <div className="pointer-events-none fixed inset-x-0 top-3 z-50 flex justify-center px-4">
      <div
        className={`animate-pop-in pointer-events-auto rounded-full px-4 py-2.5 text-[13px] font-medium text-white shadow-lg ${VARIANT_STYLES[variant]}`}
      >
        {message}
      </div>
    </div>
  );
}
