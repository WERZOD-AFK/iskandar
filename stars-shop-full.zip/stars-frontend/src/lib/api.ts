import { getInitData } from "./telegram";
import type { CreateOrderResponse, Order, Product, UserProfile } from "../types";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL as string;

class ApiRequestError extends Error {
  constructor(
    public status: number,
    message: string,
  ) {
    super(message);
  }
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      "X-Telegram-Init-Data": getInitData(),
      ...options.headers,
    },
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new ApiRequestError(res.status, body.detail ?? "Xatolik yuz berdi");
  }

  return res.json() as Promise<T>;
}

export const api = {
  listProducts: () => request<Product[]>("/api/public/products"),

  me: () => request<UserProfile>("/api/public/me"),

  myOrders: () => request<Order[]>("/api/public/orders"),

  orderStatus: (orderId: number) => request<Order>(`/api/public/orders/${orderId}`),

  createOrder: (productId: number, promoCode?: string) =>
    request<CreateOrderResponse>(
      `/api/public/orders?product_id=${productId}${promoCode ? `&promo_code=${encodeURIComponent(promoCode)}` : ""}`,
      { method: "POST" },
    ),

  submitSupportTicket: (message: string) =>
    request<{ id: number }>("/api/public/support/tickets", {
      method: "POST",
      body: JSON.stringify({ message }),
    }),
};

export { ApiRequestError };
