/**
 * Telegram Mini App JS SDK (index.html'da <script> orqali ulangan)
 * uchun yengil, tip-xavfsiz wrapper. Brauzerda (Telegram tashqarisida)
 * ochilganda ham xato bermasligi uchun har bir chaqiruv ixtiyoriy.
 */

interface TelegramWebApp {
  initData: string;
  initDataUnsafe: {
    user?: {
      id: number;
      first_name: string;
      last_name?: string;
      username?: string;
      language_code?: string;
    };
  };
  colorScheme: "light" | "dark";
  themeParams: Record<string, string>;
  ready: () => void;
  expand: () => void;
  disableVerticalSwipes?: () => void;
  setHeaderColor?: (color: string) => void;
  setBackgroundColor?: (color: string) => void;
  onEvent: (eventType: string, callback: () => void) => void;
  offEvent: (eventType: string, callback: () => void) => void;
  openInvoice: (url: string, callback: (status: "paid" | "cancelled" | "failed" | "pending") => void) => void;
  openTelegramLink: (url: string) => void;
  HapticFeedback?: {
    impactOccurred: (style: "light" | "medium" | "heavy" | "rigid" | "soft") => void;
    notificationOccurred: (type: "error" | "success" | "warning") => void;
    selectionChanged: () => void;
  };
  BackButton: {
    show: () => void;
    hide: () => void;
    onClick: (cb: () => void) => void;
    offClick: (cb: () => void) => void;
  };
}

declare global {
  interface Window {
    Telegram?: { WebApp: TelegramWebApp };
  }
}

function getWebApp(): TelegramWebApp | null {
  return window.Telegram?.WebApp ?? null;
}

export function initTelegramApp(): void {
  const app = getWebApp();
  if (!app) return;

  app.ready();
  app.expand();
  app.disableVerticalSwipes?.();
  applyThemeVars();
  app.onEvent("themeChanged", applyThemeVars);
}

/** Telegram mavzu ranglarini CSS o'zgaruvchilariga o'tkazadi (index.css/tailwind shulardan foydalanadi). */
function applyThemeVars(): void {
  const app = getWebApp();
  const root = document.documentElement.style;
  const t = app?.themeParams ?? {};

  root.setProperty("--tg-bg", t.bg_color ?? "#ffffff");
  root.setProperty("--tg-secondary-bg", t.secondary_bg_color ?? "#f0f0f3");
  root.setProperty("--tg-text", t.text_color ?? "#0f1115");
  root.setProperty("--tg-hint", t.hint_color ?? "#8a8f98");
  root.setProperty("--tg-link", t.link_color ?? "#2aabee");
  root.setProperty("--tg-button", t.button_color ?? "#2aabee");
  root.setProperty("--tg-button-text", t.button_text_color ?? "#ffffff");
}

export function getInitData(): string {
  return getWebApp()?.initData ?? "";
}

export function getTelegramUser() {
  return getWebApp()?.initDataUnsafe?.user ?? null;
}

export function haptic(style: "light" | "medium" | "heavy" = "light"): void {
  getWebApp()?.HapticFeedback?.impactOccurred(style);
}

export function hapticSuccess(): void {
  getWebApp()?.HapticFeedback?.notificationOccurred("success");
}

export function hapticError(): void {
  getWebApp()?.HapticFeedback?.notificationOccurred("error");
}

export function openInvoice(url: string): Promise<"paid" | "cancelled" | "failed" | "pending"> {
  return new Promise((resolve) => {
    const app = getWebApp();
    if (!app) {
      // Brauzerda test qilinayotganda — yangi tabda ochamiz, natijani qo'lda tekshirish kerak bo'ladi
      window.open(url, "_blank");
      resolve("pending");
      return;
    }
    app.openInvoice(url, (status) => resolve(status));
  });
}

export function isInsideTelegram(): boolean {
  return getWebApp() !== null;
}
