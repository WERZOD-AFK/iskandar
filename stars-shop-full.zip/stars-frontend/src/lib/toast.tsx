import { createContext, useCallback, useContext, useState, type ReactNode } from "react";
import { Toast } from "../components/Toast";

type ToastVariant = "success" | "error" | "info";

interface ToastState {
  id: number;
  message: string;
  variant: ToastVariant;
}

const ToastContext = createContext<(message: string, variant?: ToastVariant) => void>(() => {});

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toast, setToast] = useState<ToastState | null>(null);

  const showToast = useCallback((message: string, variant: ToastVariant = "info") => {
    setToast({ id: Date.now(), message, variant });
  }, []);

  return (
    <ToastContext.Provider value={showToast}>
      {children}
      {toast && <Toast key={toast.id} message={toast.message} variant={toast.variant} onDone={() => setToast(null)} />}
    </ToastContext.Provider>
  );
}

export function useToast() {
  return useContext(ToastContext);
}
