import { useEffect, useState } from "react";
import { StarIcon } from "../components/StarIcon";
import { ProductCard } from "../components/ProductCard";
import { api, ApiRequestError } from "../lib/api";
import { getTelegramUser, hapticError, hapticSuccess, openInvoice } from "../lib/telegram";
import { useToast } from "../lib/toast";
import type { Product } from "../types";

export function Home() {
  const [products, setProducts] = useState<Product[] | null>(null);
  const [loadError, setLoadError] = useState(false);
  const [pendingProductId, setPendingProductId] = useState<number | null>(null);
  const [promoCode, setPromoCode] = useState("");
  const [promoOpen, setPromoOpen] = useState(false);
  const showToast = useToast();
  const tgUser = getTelegramUser();

  useEffect(() => {
    api
      .listProducts()
      .then(setProducts)
      .catch(() => setLoadError(true));
  }, []);

  async function handleBuy(product: Product) {
    setPendingProductId(product.id);
    try {
      const { invoice_link } = await api.createOrder(product.id, promoCode.trim() || undefined);
      const status = await openInvoice(invoice_link);

      if (status === "paid") {
        hapticSuccess();
        showToast("✅ To'lov muvaffaqiyatli!", "success");
      } else if (status === "cancelled") {
        showToast("To'lov bekor qilindi", "info");
      } else if (status === "failed") {
        hapticError();
        showToast("To'lovda xatolik yuz berdi", "error");
      }
    } catch (err) {
      hapticError();
      const message = err instanceof ApiRequestError ? err.message : "Buyurtma yaratib bo'lmadi";
      showToast(message, "error");
    } finally {
      setPendingProductId(null);
    }
  }

  const popular = products?.find((p) => p.is_popular);
  const rest = products?.filter((p) => p.id !== popular?.id) ?? [];

  return (
    <div className="px-4 pb-4 pt-2">
      {/* Header */}
      <div className="flex items-center gap-3 py-3">
        <div className="flex h-11 w-11 items-center justify-center rounded-full bg-tgsecondary text-lg font-semibold text-tgtext">
          {tgUser?.first_name?.[0]?.toUpperCase() ?? "★"}
        </div>
        <div>
          <p className="text-[15px] font-semibold text-tgtext">
            Assalomu alaykum{tgUser?.first_name ? `, ${tgUser.first_name}` : ""} 👋
          </p>
          <p className="text-[12px] text-tghint">Stars sotib olishga xush kelibsiz</p>
        </div>
      </div>

      {/* Hero */}
      <div className="relative mb-5 overflow-hidden rounded-3xl bg-tgsecondary px-5 py-6">
        <StarIcon className="absolute -right-3 -top-3 h-24 w-24 rotate-12 opacity-10" />
        <StarIcon className="absolute -bottom-4 left-8 h-10 w-10 -rotate-12 animate-float opacity-15" />
        <p className="text-[13px] font-medium text-tghint">⭐ Telegram Stars</p>
        <p className="mt-1 text-[20px] font-bold leading-tight text-tgtext">
          Har qanday xizmat uchun
          <br />
          bir necha soniyada
        </p>
      </div>

      {loadError && (
        <div className="rounded-2xl bg-tgsecondary p-4 text-center text-[13px] text-tghint">
          Paketlarni yuklab bo'lmadi. Iltimos, birozdan so'ng qayta urinib ko'ring.
        </div>
      )}

      {!loadError && !products && (
        <div className="space-y-3">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-16 animate-pulse rounded-2xl bg-tgsecondary" />
          ))}
        </div>
      )}

      {popular && (
        <div className="mb-3">
          <ProductCard product={popular} onBuy={handleBuy} busy={pendingProductId === popular.id} />
        </div>
      )}

      {/* Promo kod */}
      <div className="mb-3">
        {!promoOpen ? (
          <button
            onClick={() => setPromoOpen(true)}
            className="text-[12px] font-medium text-tglink"
          >
            🎟 Promo kodingiz bormi?
          </button>
        ) : (
          <div className="flex items-center gap-2 rounded-2xl bg-tgsecondary px-3.5 py-2.5">
            <input
              value={promoCode}
              onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
              placeholder="PROMO10"
              className="min-w-0 flex-1 bg-transparent text-[13px] text-tgtext placeholder:text-tghint focus:outline-none"
            />
            {promoCode && (
              <span className="shrink-0 text-[11px] font-semibold text-emerald-500">✓ qo'llaniladi</span>
            )}
          </div>
        )}
      </div>

      {rest.length > 0 && (
        <>
          <p className="mb-2 mt-5 text-[13px] font-semibold text-tghint">Barcha paketlar</p>
          <div className="grid grid-cols-2 gap-2.5">
            {rest.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onBuy={handleBuy}
                busy={pendingProductId === product.id}
              />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
