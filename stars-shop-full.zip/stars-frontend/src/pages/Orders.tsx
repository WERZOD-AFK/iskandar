import { useEffect, useState } from "react";
import { StarIcon } from "../components/StarIcon";
import { StatusBadge } from "../components/StatusBadge";
import { api } from "../lib/api";
import type { Order } from "../types";

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString("uz-UZ", { day: "2-digit", month: "2-digit", year: "numeric" });
}

export function Orders() {
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [loadError, setLoadError] = useState(false);

  useEffect(() => {
    api
      .myOrders()
      .then(setOrders)
      .catch(() => setLoadError(true));
  }, []);

  return (
    <div className="px-4 pb-4 pt-2">
      <h1 className="py-3 text-[19px] font-bold text-tgtext">📦 Buyurtmalarim</h1>

      {loadError && (
        <div className="rounded-2xl bg-tgsecondary p-4 text-center text-[13px] text-tghint">
          Buyurtmalarni yuklab bo'lmadi.
        </div>
      )}

      {!loadError && !orders && (
        <div className="space-y-2.5">
          {[0, 1, 2].map((i) => (
            <div key={i} className="h-[70px] animate-pulse rounded-2xl bg-tgsecondary" />
          ))}
        </div>
      )}

      {orders && orders.length === 0 && (
        <div className="flex flex-col items-center gap-2 rounded-2xl bg-tgsecondary py-10 text-center">
          <StarIcon className="h-8 w-8 opacity-40" />
          <p className="text-[14px] font-medium text-tgtext">Hali buyurtmalar yo'q</p>
          <p className="px-8 text-[12px] text-tghint">Bosh sahifadan Stars paketini tanlab, birinchi xaridingizni qiling</p>
        </div>
      )}

      <div className="space-y-2.5">
        {orders?.map((order) => (
          <div key={order.id} className="flex items-center gap-3 rounded-2xl bg-tgsecondary px-4 py-3.5">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-star/15">
              <StarIcon className="h-5 w-5" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-[14px] font-semibold tabular-nums text-tgtext">
                {order.stars_amount.toLocaleString("ru-RU")} Stars
              </p>
              <p className="text-[12px] text-tghint">
                #{order.id} · {formatDate(order.created_at)}
              </p>
            </div>
            <StatusBadge status={order.status} />
          </div>
        ))}
      </div>
    </div>
  );
}
