import { useEffect, useState } from "react";
import { api, ApiRequestError } from "../lib/api";
import { getTelegramUser, haptic } from "../lib/telegram";
import { useToast } from "../lib/toast";
import type { UserProfile } from "../types";

export function Profile() {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [supportOpen, setSupportOpen] = useState(false);
  const [supportText, setSupportText] = useState("");
  const [sending, setSending] = useState(false);
  const showToast = useToast();
  const tgUser = getTelegramUser();

  useEffect(() => {
    api.me().then(setProfile).catch(() => {});
  }, []);

  async function submitSupport() {
    if (!supportText.trim()) return;
    setSending(true);
    try {
      await api.submitSupportTicket(supportText.trim());
      showToast("✅ Xabaringiz yuborildi", "success");
      setSupportText("");
      setSupportOpen(false);
    } catch (err) {
      const message = err instanceof ApiRequestError ? err.message : "Yuborib bo'lmadi";
      showToast(message, "error");
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="px-4 pb-4 pt-2">
      <h1 className="py-3 text-[19px] font-bold text-tgtext">👤 Profil</h1>

      <div className="flex items-center gap-3 rounded-2xl bg-tgsecondary px-4 py-4">
        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-tgbutton text-[17px] font-semibold text-tgbuttontext">
          {tgUser?.first_name?.[0]?.toUpperCase() ?? "?"}
        </div>
        <div>
          <p className="text-[15px] font-semibold text-tgtext">
            {tgUser ? `${tgUser.first_name} ${tgUser.last_name ?? ""}`.trim() : "Foydalanuvchi"}
          </p>
          <p className="text-[12px] text-tghint">@{tgUser?.username ?? profile?.username ?? "—"}</p>
        </div>
      </div>

      <div className="mt-3 grid grid-cols-3 gap-2.5">
        <StatCard label="Sotib olingan" value={profile ? profile.total_stars_purchased.toLocaleString("ru-RU") : "—"} />
        <StatCard label="Buyurtmalar" value={profile ? String(profile.orders_count) : "—"} />
        <StatCard label="Bonus" value={profile ? String(profile.bonus_balance) : "—"} />
      </div>

      <p className="mb-2 mt-6 text-[13px] font-semibold text-tghint">Yordam</p>
      <div className="overflow-hidden rounded-2xl bg-tgsecondary">
        <button
          onClick={() => {
            haptic("light");
            setSupportOpen((v) => !v);
          }}
          className="flex w-full items-center justify-between px-4 py-3.5 text-left text-[14px] text-tgtext"
        >
          ✍️ Savol yuborish
          <span className="text-tghint">{supportOpen ? "︿" : "﹀"}</span>
        </button>

        {supportOpen && (
          <div className="border-t border-tghint/15 px-4 py-3.5">
            <textarea
              value={supportText}
              onChange={(e) => setSupportText(e.target.value)}
              placeholder="Savolingizni yozing..."
              rows={3}
              className="w-full resize-none rounded-xl bg-tgbg px-3 py-2.5 text-[13px] text-tgtext placeholder:text-tghint focus:outline-none"
            />
            <button
              onClick={submitSupport}
              disabled={sending || !supportText.trim()}
              className="mt-2 w-full rounded-xl bg-tgbutton py-2.5 text-[13px] font-semibold text-tgbuttontext disabled:opacity-50"
            >
              {sending ? "Yuborilmoqda..." : "Yuborish"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

function StatCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-tgsecondary px-3 py-3 text-center">
      <p className="text-[15px] font-bold tabular-nums text-tgtext">{value}</p>
      <p className="mt-0.5 text-[11px] text-tghint">{label}</p>
    </div>
  );
}
