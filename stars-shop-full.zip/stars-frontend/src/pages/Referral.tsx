import { useState } from "react";
import { StarIcon } from "../components/StarIcon";
import { getTelegramUser, haptic } from "../lib/telegram";
import { useToast } from "../lib/toast";

const BOT_USERNAME = import.meta.env.VITE_BOT_USERNAME;

export function Referral() {
  const [copied, setCopied] = useState(false);
  const showToast = useToast();
  const tgUser = getTelegramUser();

  const refLink = tgUser ? `https://t.me/${BOT_USERNAME}?start=ref_${tgUser.id}` : "";

  async function handleCopy() {
    haptic("light");
    try {
      await navigator.clipboard.writeText(refLink);
      setCopied(true);
      showToast("Havola nusxalandi", "success");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      showToast("Nusxalab bo'lmadi", "error");
    }
  }

  return (
    <div className="px-4 pb-4 pt-2">
      <h1 className="py-3 text-[19px] font-bold text-tgtext">🎁 Referal va bonuslar</h1>

      <div className="relative overflow-hidden rounded-3xl bg-tgsecondary px-5 py-6 text-center">
        <StarIcon className="mx-auto mb-3 h-12 w-12 animate-float" />
        <p className="text-[15px] font-semibold text-tgtext">Do'stlaringizni taklif qiling</p>
        <p className="mx-auto mt-1 max-w-[240px] text-[12px] text-tghint">
          Do'stingiz havola orqali kirib Stars sotib olsa, siz bonus olasiz
        </p>
      </div>

      <p className="mb-2 mt-5 text-[13px] font-semibold text-tghint">Sizning havolangiz</p>
      <button
        onClick={handleCopy}
        className="flex w-full items-center justify-between gap-2 rounded-2xl bg-tgsecondary px-4 py-3.5 text-left"
      >
        <span className="truncate text-[13px] text-tgtext">{refLink || "Yuklanmoqda..."}</span>
        <span className="shrink-0 rounded-full bg-tgbutton px-3 py-1.5 text-[12px] font-semibold text-tgbuttontext">
          {copied ? "✓" : "Nusxalash"}
        </span>
      </button>

      <p className="mt-6 text-center text-[12px] text-tghint">
        Bonus balansingizni Profil bo'limidan kuzatib borishingiz mumkin.
      </p>
    </div>
  );
}
