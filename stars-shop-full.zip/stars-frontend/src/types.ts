export type OrderStatus = "pending" | "paid" | "processing" | "completed" | "cancelled";

export interface Product {
  id: number;
  name: string;
  stars_amount: number;
  price_stars: number;
  is_active: boolean;
  is_popular: boolean;
}

export interface Order {
  id: number;
  stars_amount: number;
  price_stars: number;
  status: OrderStatus;
  promo_code: string | null;
  created_at: string;
  paid_at: string | null;
}

export interface UserProfile {
  tg_user_id: number;
  username: string | null;
  full_name: string;
  bonus_balance: number;
  is_blocked: boolean;
  total_stars_purchased: number;
  orders_count: number;
}

export interface CreateOrderResponse {
  order: Order;
  invoice_link: string;
}
